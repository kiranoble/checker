<?php
# ------------ [ TIMEZONE ] -------------------- #

if ($_SERVER['REQUEST_METHOD'] == "POST") {
    extract($_POST);
} elseif ($_SERVER['REQUEST_METHOD'] == "GET") {
    extract($_GET);
    $time_start = microtime(true);
}
# ---------------- [ PHP ] ------------------- #

// Separate input string by "|"
$separa = explode("|", $lista);
$cc = $separa[0];
$mes = $separa[1];
$ano = $separa[2];
$cvv = $separa[3];

// Format credit card parts
$cc1 = substr($cc, 0, 4);
$cc2 = substr($cc, 4, 4);
$cc3 = substr($cc, 8, 4);
$cc4 = substr($cc, 12, 4);
$cc6 = substr($cc, 0, 6);

// Determine card type based on prefix
if (substr($cc, 0, 1) == '4') {
    $ctype = 'visa';
} elseif (substr($cc, 0, 1) == '5') {
    $ctype = 'mastercard';
} elseif (substr($cc, 0, 2) == '34' || substr($cc, 0, 2) == '37') {
    $ctype = 'americanexpress';
} elseif (substr($cc, 0, 4) == '6011' || substr($cc, 0, 2) == '65' || (substr($cc, 0, 6) >= '622126' && substr($cc, 0, 6) <= '622925')) {
    $ctype = 'discover';
} else {
    $ctype = 'unknown';
}

// Set brand and other card type representations
$brand = match ($ctype) {
    'visa' => 'Visa',
    'mastercard' => 'MasterCard',
    'americanexpress' => 'American Express',
    'discover' => 'Discover',
    default => 'Unknown'
};

$ctype1 = match ($ctype) {
    'visa' => 'VI',
    'mastercard' => 'MC',
    'americanexpress' => 'AE',
    'discover' => 'DI',
    default => null
};

$ctype2 = $brand;
$ctype3 = strtoupper($brand);

$ctype4 = match ($ctype) {
    'visa' => '001',
    'mastercard' => '002',
    'americanexpress' => '003',
    'discover' => '004',
    default => null
};

// Format year to ensure it follows the "20XX" format if not already
if (strlen($ano) === 2) {
    $ano = '20' . $ano;
}

// Remove leading zero from the month if present
 $mes1 = ltrim($mes, '0');

// Outputs: mes with leading zero, ano with "20" prefix
$mes_with_zero = str_pad($mes1, 2, '0', STR_PAD_LEFT);
$ano_with_20 = $ano;

// Outputs: mes without leading zero, ano without "20" prefix
 $ano_no_20 = substr($ano, -2);

# -------------- [ FUNCTIONS ] -------- #


function GetStr($string, $start, $end) {
    $str = explode($start, $string);
    $str = explode($end, $str[1]);  
    return $str[0];
}
function inStr($string, $start, $end, $value) {
    $str = explode($start, $string);
    $str = explode($end, $str[$value]);
    return $str[0];
}
# ----------- [ random cookies ] ----- #

$inst = [
  'cookie' => mt_rand().'.txt'
];
$cookay = ''.getcwd().'/COOKIE';

if (!is_dir($cookay)) {
    mkdir($cookay, 0777, true);
}
$curttt1 = getcwd();
$curttzy = str_replace('\\', '/', $curttt1);

# ---------- [ FORMKEY ] --- #
function GetRandomWord($len = 20) {

    $word = array_merge(range('a', 'z'), range('A', 'Z'));

    shuffle($word);
    return substr(implode($word), 0, $len);
}
$rcocks = GetRandomWord();
$formkey = substr(str_shuffle(mt_rand().mt_rand().$rcocks), 0, 16);
$Webkit = substr(str_shuffle(mt_rand().mt_rand().$Random), 0, 16);

# ---------------- [ DEVICE/CORRELATION ID ] ----- #
function DeviceID($length)
{
    $characters       = '0123456789abcdefghijklmnopqrstuvwxyz';
    $charactersLength = strlen($characters);
    $randomString     = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }
    return $randomString;
}
 // Function to generate part of GUID-like strings
function s($length)
{
    return DeviceID($length);
}

$DeviceSessionID = DeviceID(32);

$guid = s(8) . '-' . s(4) . '-' . s(4) . '-' . s(4) . '-' . s(12);
$muid = s(8) . '-' . s(4) . '-' . s(4) . '-' . s(4) . '-' . s(12);
$sid = s(8) . '-' . s(4) . '-' . s(4) . '-' . s(4) . '-' . s(12);
$sessionId = s(8) . '-' . s(4) . '-' . s(4) . '-' . s(4) . '-' . s(12);

    # -------------- [ START PROXY ] -------------- #
$proxyuser = '';

if (isset($_POST['proxy']) || isset($_GET['proxy'])) {
    $proxyuser = $_POST['proxy'] ?? $_GET['proxy'];
}

$proxy_port = '';
$user_pass = '';

if (!empty($proxyuser)) {
    $proxy_parts = explode(':', $proxyuser);
    
    if (count($proxy_parts) >= 2) {
        $proxy_port = $proxy_parts[0] . ':' . $proxy_parts[1];
    }

    if (count($proxy_parts) == 4) {
        $user_pass = $proxy_parts[2] . ':' . $proxy_parts[3];
    }
}

function setupCurlProxy($ch, $proxy_port, $user_pass) {
    if (!empty($proxy_port)) {
        curl_setopt($ch, CURLOPT_PROXY, $proxy_port);
        curl_setopt($ch, CURLOPT_TIMEOUT, 20);
    }
    if (!empty($user_pass)) {
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $user_pass);
    }
}

function fetchCurrentIp($proxy_port = '', $user_pass = '') {
    $ch = curl_init();
    $urlToGet = 'https://ip.zxq.co/';
    curl_setopt($ch, CURLOPT_URL, $urlToGet);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);

    // Set up proxy if provided
    if (!empty($proxy_port)) {
        setupCurlProxy($ch, $proxy_port, $user_pass);
    }

    // Execute cURL and get response
    $ipdata = curl_exec($ch);
    $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);

    // Handle cURL errors
    if ($ipdata === false) {
        $error = curl_error($ch);
         "cURL Error: $error\n";
        curl_close($ch);
        return false;
    }

    curl_close($ch);

    // Handle HTTP errors
    if ($http_code !== 200) {
        echo "HTTP Error: $http_code\n";
        return false;
    }

    // Decode JSON response and check if 'ip' field exists
    $responseData = json_decode($ipdata, true);
    if (isset($responseData['ip'])) {
        $query = $responseData['ip']; // Get the IP address

        // Mask the last two parts of the IP address
        $ipParts = explode('.', $query);
        $ipParts[2] = 'xxx';
        $ipParts[3] = 'xx';

        // Return the masked IP address
        return implode('.', $ipParts);
    } else {
         "IP address not found in the response.\n";
        return false;
    }
}

// Example usage:
$ip = fetchCurrentIp($proxy_port, $user_pass);
if ($ip !== false) {
     "Masked IP: $ip\n";
}

?>