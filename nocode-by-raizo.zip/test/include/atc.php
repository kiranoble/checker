<?php

#--------------------- [ INPUT SITE ] ------------------#

$urls = explode(',', $_GET['website']);
$random_url = $urls[array_rand($urls)];
$parsed_url = parse_url(trim($random_url));
$product_page_url = $random_url;
$url2 = parse_url($product_page_url);
$hostname = $url2['host'];

# ------------- [ RESPONSES ] ------------------ #
$time_start = microtime(true);
$badge_cvv = '<span style="background-color: green; color: white; padding: 2px 5px; border-radius: 5px; font-size: 12px;">#CVV</span>';
$badge_ccn = '<span style="background-color: green; color: white; padding: 2px 5px; border-radius: 5px; font-size: 12px;">#CCN</span>';
$badge_declined = '<span style="background-color: red; color: white; padding: 2px 5px; border-radius: 5px; font-size: 12px;">#DEAD</span>';

$hostname1 = (strpos($hostname, 'http') !== 0) ? 'http://' . $hostname : $hostname;

$product_found = false;
$final_url = null;

# --- [ CURL fetch original product page ] --- #

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $product_page_url);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    'accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.7',
    'accept-language: en-US,en;q=0.9',
    'cache-control: max-age=0',
    'origin: https://' . $hostname,
    'authority: https://' . $hostname,
    'content-type: application/x-www-form-urlencoded; charset=UTF-8',
    'referer: https://' . $hostname . '/cart',
    'sec-fetch-dest: document',
    'sec-fetch-mode: navigate',
    'sec-fetch-site: same-origin',
    'sec-fetch-user: ?1',
    'upgrade-insecure-requests: 1',
    'user-agent: ' . $ua,
));
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_PROXY, $proxy_port);
curl_setopt($ch, CURLOPT_PROXYUSERPWD, $user_pass);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
curl_setopt($ch, CURLOPT_COOKIEFILE, "" . $curttt1 . "/COOKIE/" . $inst['cookie'] . "");
curl_setopt($ch, CURLOPT_COOKIEJAR, "" . $curttt1 . "/COOKIE/" . $inst['cookie'] . "");
$product_page_content = curl_exec($ch);
curl_close($ch);

$dom = new DOMDocument();
@$dom->loadHTML($product_page_content);
$xpath = new DOMXPath($dom);

$product_id = null;
$variation_data = null;

$form_nodes = $xpath->query('//form[@class="variations_form cart"]');
if ($form_nodes->length > 0) {
    $form_node = $form_nodes->item(0);
    $product_id = $form_node->getAttribute('data-product_id');
    $variation_data_attr = $form_node->getAttribute('data-product_variations');
    if ($variation_data_attr !== "false") {
        $variation_data = json_decode(html_entity_decode($variation_data_attr), true);
    }
}

if (!$product_id) {
    $product_id_node = $xpath->query('//input[@name="product_id" or @name="add-to-cart"]');
    if ($product_id_node->length > 0) {
        $product_id = $product_id_node->item(0)->getAttribute('value');
    }
}

if (!$product_id) {
    $button_node = $xpath->query('//button[@name="add-to-cart"]');
    if ($button_node->length > 0) {
        $product_id = $button_node->item(0)->getAttribute('value');
    }
}

# --- [ If product found on first page ] --- #

if ($product_id) {
    $base_url = $product_page_url;
    $query_params = [
        'quantity' => 1,
        'add-to-cart' => $product_id
    ];

    if ($variation_data) {
        $first_variation = $variation_data[0];
        $variation_id = $first_variation['variation_id'];
        $attributes = $first_variation['attributes'];

        $query_params['attribute_' . key($attributes)] = reset($attributes);
        $query_params['product_id'] = $product_id;
        $query_params['variation_id'] = $variation_id;
    }

    $final_url = $base_url . '?' . http_build_query($query_params);
    $product_found = true;
}

# --- [ If not found, try fallback pages ] --- #

if (!$product_found) {
    $paths_to_try = ['/shop', '/product', '/product-category', '/store', '/'];

    foreach ($paths_to_try as $path) {
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, rtrim($hostname1, '/') . $path);
        curl_setopt($ch, CURLOPT_HEADER, 0);
        curl_setopt($ch, CURLOPT_HTTPHEADER, array(
            'user-agent: ' . $ua,
        ));
        curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_PROXY, $proxy_port);
        curl_setopt($ch, CURLOPT_PROXYUSERPWD, $user_pass);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
        $page_content = curl_exec($ch);
        curl_close($ch);

        $dom = new DOMDocument();
        @$dom->loadHTML($page_content);
        $xpath = new DOMXPath($dom);

        $link_nodes = $xpath->query('//a[contains(@href, "/product/") or contains(@href, "/store/") or contains(@href, "/shop/")]');

        $product_links = [];
        foreach ($link_nodes as $link_node) {
            $href = $link_node->getAttribute('href');
            if (!empty($href)) {
                if (strpos($href, 'http') !== 0) {
                    $href = rtrim($hostname1, '/') . '/' . ltrim($href, '/');
                }
                $product_links[] = $href;
            }
        }

        shuffle($product_links);

        foreach ($product_links as $product_page_url) {
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $product_page_url);
            curl_setopt($ch, CURLOPT_HEADER, 0);
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                'user-agent: ' . $ua,
            ));
            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($ch, CURLOPT_PROXY, $proxy_port);
            curl_setopt($ch, CURLOPT_PROXYUSERPWD, $user_pass);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($ch, CURLOPT_ENCODING, 'gzip, deflate');
            $product_page_content = curl_exec($ch);
            curl_close($ch);

            $dom = new DOMDocument();
            @$dom->loadHTML($product_page_content);
            $xpath = new DOMXPath($dom);

            $product_id = null;
            $variation_data = null;

            $form_nodes = $xpath->query('//form[@class="variations_form cart"]');
            if ($form_nodes->length > 0) {
                $form_node = $form_nodes->item(0);
                $product_id = $form_node->getAttribute('data-product_id');
                $variation_data_attr = $form_node->getAttribute('data-product_variations');
                if ($variation_data_attr !== "false") {
                    $variation_data = json_decode(html_entity_decode($variation_data_attr), true);
                }
            }

            if (!$product_id) {
                $product_id_node = $xpath->query('//input[@name="product_id" or @name="add-to-cart"]');
                if ($product_id_node->length > 0) {
                    $product_id = $product_id_node->item(0)->getAttribute('value');
                }
            }

            if (!$product_id) {
                $button_node = $xpath->query('//button[@name="add-to-cart"]');
                if ($button_node->length > 0) {
                    $product_id = $button_node->item(0)->getAttribute('value');
                }
            }

            if ($product_id) {
                $base_url = $product_page_url;
                $query_params = [
                    'quantity' => 1,
                    'add-to-cart' => $product_id
                ];

                if ($variation_data) {
                    $first_variation = $variation_data[0];
                    $variation_id = $first_variation['variation_id'];
                    $attributes = $first_variation['attributes'];

                    $query_params['attribute_' . key($attributes)] = reset($attributes);
                    $query_params['product_id'] = $product_id;
                    $query_params['variation_id'] = $variation_id;
                }

                $final_url = $base_url . '?' . http_build_query($query_params);
                $product_found = true;
                break 2;
            }
        }
    }
}

# --- [ FINAL OUTPUT HERE ] --- #

if ($product_found && $final_url) {
     'Final URL: ' . $final_url;
} else {
    echo '
            <div style="font-size: 14px;">
                ' . $badge_declined . ' ' . $lista . ' [ CANT FIND PRODUCT ] [AMOUNT: '.$price1.'] [' . $ip . '] <a href="' . $hostname1 . '" target="_blank">SITE</a> <br>
            </div>
        ';
    exit;
}

?>
