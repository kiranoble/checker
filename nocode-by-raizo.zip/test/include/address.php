<?php

if (str_ends_with($site2, '.co.uk') || str_ends_with($site2, '.uk.com')) {
    $country = 'GB';  // Set country to 'GB' for the UK
} elseif (str_ends_with($site2, '.au') || $site2 == 'www.spearfishingaustralia.com') {
    $country = 'AU';
} elseif (str_ends_with($site2, '.ca')) {
    $country = 'CA';
} elseif ($site2 == 'www.hdsecure-cctv.com' || $site2 == 'www.sellatronic.net') {
    $country = 'GB';  // Set country to 'GB' for specific sites
} elseif ($site2 == 'anapharmacy.com') {
    $country = 'AL';
} else {
    $country = 'US';
}

// Set the country for the API URL
$apiCountry = strtolower($country);
if ($apiCountry === 'gb') {
    $apiCountry = 'uk';  // Use 'uk' for the API request, but keep $country as 'GB'
}

$apiUrl = "https://randomuser.me/api/?nat=" . $apiCountry;

// Initialize cURL
$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL => $apiUrl,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false,
]);

$response = curl_exec($ch);
curl_close($ch);

// Decode JSON response
$data = json_decode($response, true);

// Check if valid
if (isset($data['results'][0])) {
    $user = $data['results'][0];

    // Name and email
    $fname = $user['name']['first'] ?? '';
    $lname = $user['name']['last'] ?? '';
    $full_name = $fname . ' ' . $lname;

    // Create randomized email using first name and domain
    $clean_fname = preg_replace('/[^a-z0-9]/i', '', strtolower($fname)); // sanitize first name for email
    $email = $clean_fname . '@gmail.com';

    // Location info
    $street = $user['location']['street']['number'] . ' ' . $user['location']['street']['name'];
    $city = $user['location']['city'] ?? '';
    $state = $user['location']['state'] ?? '';
    $zip = $user['location']['postcode'] ?? '';
    $country_from_api = $user['location']['country'] ?? '';

    // Get nat value
    $country = $user['nat'] ?? '';
    $username = $user['login']['username'] ?? '';
    $password = $user['login']['password'] ?? '';
    $phone = $user['phone'] ?? '';

}

?>